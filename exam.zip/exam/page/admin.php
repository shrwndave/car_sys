<?php
    include_once "../model/model.php";

    $page_info['page'] = 'home';
    $page_info['sub_page'] =isset($_GET['sub_page']) ? $_GET['sub_page'] : 'home';

    session_start();
    if(!isset($_SESSION['id'])){
        header('Location: authentication.php');
        exit;
    }else{
        try{
            if(isset($_GET['function'])){
                new adminActive($page_info);
            }else{
                new admin($page_info);
            }
        }catch(Throwable $e){
			echo "<div class='content-wrapper'><h1 style='text-align: center; font-size: 150px; margin-top: 350px'>404 ERROR PAGE</h1>";
			echo "<p style='text-align: center;'> " . $e->getMessage() . "</p>";
			echo "
				<div style='align-items: center; justify-content: center; position: absolute; display: flex; width: 100%; margin-top: 40px'>
					<a href='?sub_page=home' style='position:relative; justify-content: center'>
						<button style='padding:10px; font-weight: bolder'>Return to Dashboard</button>
					</a>
				</div></div>
			";
        }
    }

    class admin{
        private $page = '';
        private $sub_page = '';

        function __construct($page_info){
            $this->page = $page_info['page'];
            $this->sub_page = $page_info['sub_page'];

            include "../views/admin/inc/header.php";
            include "../views/admin/inc/nav.php";
            $this->{$page_info['sub_page']}();
            
            include "../views/admin/inc/footer.php";
        }

        function home(){
            $model = new authenticationModel();

            include "../views/admin/home.php";
        }

        function candidates(){
            $model = new model();
            $candidates = $model->getCandidates();
            $positions = $model->getPositions();
            $voters = $model->getVoters();

            include "../views/admin/candidate.php";
        }

        function positions(){
            $model = new model();
            $positions = $model->getPositions();
            include "../views/admin/position.php";
        }

        function voters(){
            $model = new model();
            $voters = $model->getVoters();
            include "../views/admin/voters.php";
        }

        function results(){
            $model = new authenticationModel();
            include "../views/admin/result.php";
        }
    }

    class adminActive{
        private $page = '';
        private $sub_page = '';

        function __construct($page_info){
            $this->page = $page_info['page'];
            $this->sub_page = $page_info['sub_page'];

            $this->{$page_info['sub_page']}();
        }

        // ----------------------------------------------------------------------Candidates----------------------------------------------------------------------------//
        function editCandidates(){
            $model = new model();
            if(isset($_POST['cnd_id']) && isset($_POST['position']) && isset($_POST['voter_id'])){
                $editCandidate = $model->editCandidate($_POST);
                header('Location: ?sub_page=candidates');
            }
        }

        function delCandidates(){
            if(isset($_POST['cnd_id'])){
                $model = new model();
                $delCandidates = $model->delCandidates($_POST);
                header('Location: ?sub_page=candidates');
            }
        }

        function addCandidates(){
            if(isset($_POST['voter_id']) && isset($_POST['position'])){
                $model = new model();
                $addPosition = $model->addCandidates($_POST);
                echo "<script>alert('ADDED SUCCESSFULLY!');window.location.href='?sub_page=candidates'</script>";
            }
        }

        // ----------------------------------------------------------------------Candidates----------------------------------------------------------------------------//

        function editPosition(){
            $model = new model();
            if(isset($_POST['id']) && isset($_POST['position']) && isset($_POST['rank'])){
                $editPosition = $model->editPosition($_POST);
                header('Location: ?sub_page=positions');
            }

        }

        function delPosition(){
            if(isset($_POST['id'])){
                $model = new model();
                $delPosition = $model->delPosition($_POST);
                header('Location: ?sub_page=positions');
            }
        }

        function addPosition(){
            if(isset($_POST['name']) && isset($_POST['rank'])){
                $model = new model();
                $addPosition = $model->addPosition($_POST);
                echo "<script>alert('ADDED SUCCESSFULLY!');window.location.href='?sub_page=positions'</script>";
            }
        }


    }
?>