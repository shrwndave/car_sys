<?php
    include_once "../model/model.php";

    $page_info['page'] = 'home';
    $page_info['sub_page'] =isset($_GET['sub_page']) ? $_GET['sub_page'] : 'home';

    session_start();
    if(!isset($_SESSION['user_id'])){
        header('Location: authentication.php');
        exit;
    }else{
        try{
            if(isset($_GET['function'])){
                new userActive($page_info);
            }else{
                new user($page_info);
            }
        }catch(Throwable $e){
			echo "<div class='content-wrapper'><h1 style='text-align: center; font-size: 150px; margin-top: 350px'>404 ERROR PAGE</h1>";
			echo "<p style='text-align: center;'> " . $e->getMessage() . "</p>";
			echo "
				<div style='align-items: center; justify-content: center; position: absolute; display: flex; width: 100%; margin-top: 40px'>
					<a href='?sub_page=home' style='position:relative; justify-content: center'>
						<button style='padding:10px; font-weight: bolder'>Return to Dashboard</button>
					</a>
				</div></div>
			";
        }
    }

    class user{
        private $page = '';
        private $sub_page = '';

        function __construct($page_info){
            $this->page = $page_info['page'];
            $this->sub_page = $page_info['sub_page'];
            
            include "../views/voter/inc/header.php";
            $this->{$page_info['sub_page']}();
            
            include "../views/voter/inc/footer.php";
        }

        function home(){
            include "../views/voter/home.php";
        }

        function vote(){
            $model = new model();
            $candidates = $model->getCandidates();
            $positions = $model->getPositions();
            $voters = $model->getVoters();

            include "../views/voter/vote.php";
        }

        function manage_vote(){
            $model = new model();
            $id = $_SESSION['user_id'];
            $vote_result = $model->getVoteResultByVotersId($id);
            if ($vote_result) {
                foreach ($vote_result as $row) {
                    // Access data from $row (e.g., $row['candidate_name'], $row['position_name'])
                    print_r($row);
                }
            } else {
                echo "Error retrieving vote results.";
            }
            include "../views/voter/manage_vote.php";
        }
    }

    class userActive{
        private $page = '';
        private $sub_page = '';

        function __construct($page_info){
            $this->page = $page_info['page'];
            $this->sub_page = $page_info['sub_page'];

            $this->{$page_info['sub_page']}();
        }


		function submitVotes() { // Original function name retained
            $model = new model();
		
			$voter = $_POST['voters_id'];
		
			$record = [];
			if (isset($_POST['vote'])) {
				foreach ($_POST['vote'] as $voted => $voted_cnd) {
					$record[] = [
						'voted' => $voted,
						'voted_cnd' => $voted_cnd,
					];
				}
			}
		
			$success = $model->submitVotes($record, $voter);

            echo "<script>alert('VOTED SUCCESSFULLY!');window.location.href='?sub_page=vote'</script>";
		}


    }
?>