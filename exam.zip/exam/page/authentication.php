<?php
    include_once "../model/model.php";

    $page_info['page'] = 'login';
    $page_info['sub_page'] =isset($_GET['sub_page']) ? $_GET['sub_page'] : 'login';

    session_start();
    if(isset($_SESSION['id']) OR isset($_SESSION['user_id']) == true){
        if($_SESSION['id'] == true){
            header('Location: admin.php');
        }elseif($_SESSION['user_id'] == true){
            header('Location: user.php');
        }
    }else{
        try{
            if(isset($_GET['function'])){
                new LoginActive($page_info);
            }else{
                new Login($page_info);
            }
        }catch(Throwable $e){
            echo '<h1 style="text-align:center">ERROR 404</h1>';
            echo $e->getMessage();
        }
    }

    class Login{
        private $page = '';
        private $sub_page = '';

        function __construct($page_info){
            $this->page = $page_info['page'];
            $this->sub_page = $page_info['sub_page'];

            $this->{$page_info['sub_page']}();
        }

        function login(){
            if(isset($_GET['loginerror'])){
                $msg = "Invalid Username or Password!";
            }
            include "../views/login.php";
        }

        function register(){
            if(isset($_GET['error'])){
                $msg = "Invalid Username or Password!";
            }
            include "../views/register.php";
        }
    }

    class LoginActive{
        private $page = '';
        private $sub_page = '';

        function __construct($page_info){
            $this->page = $page_info['page'];
            $this->sub_page = $page_info['sub_page'];

            $this->{$page_info['sub_page']}();
        }

        function loggedin(){
            $model = new authenticationModel();
            $login = $model->Login($_POST);
            $userlogin = $model->userLogin($_POST);

            if($login == true){
                $_SESSION['id'] = $login['id'];
                header('Location: admin.php');
                exit(); 
            }elseif($userlogin == true){
                $_SESSION['user_id'] = $userlogin['id'];
                $_SESSION['name'] = $userlogin['name'];
                $_SESSION['contact'] = $userlogin['contact'];
                $_SESSION['address'] = $userlogin['address'];
                header('Location: user.php');
                exit(); 
            }else{
                header('Location: ?sub_page=login&&loginerror');
            }

        }

        function registered(){

        }

    }
?>