<?php

class Connector{
	
	//database variables
	private $servername = "192.168.80.165";
	private $username = "user_e2ps";
	private $password = "e2ps";
	
	protected $conn;
	function __construct(){
		try {
			$this->conn = new PDO("mysql:host=$this->servername;dbname=voting_db", $this->username, $this->password);
			// set the PDO error mode to exception
			$this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
			//echo "Connected successfully";
		} catch(PDOException $e) {
			echo "Connection failed: " . $e->getMessage();
		}
	}
}




