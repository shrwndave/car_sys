<?php 
require_once 'connector.php';

class authenticationModel extends Connector{
    function __construct(){
        parent::__construct();
    }


    function Login($post){
        $sql = "SELECT * FROM `admin_users` WHERE username = ? AND password = ?";

        $query = $this->conn->prepare($sql);
        
        $query->bindParam(1, $post['username']);
        $query->bindParam(2, $post['password']);
        $query->execute();
        return $query->fetch(PDO::FETCH_ASSOC);
    }

    function userLogin($post){
        $sql = "SELECT * FROM `voters` WHERE username = ? AND password = ?";

        $query = $this->conn->prepare($sql);
        
        $query->bindParam(1, $post['username']);
        $query->bindParam(2, $post['password']);
        $query->execute();
        return $query->fetch(PDO::FETCH_ASSOC);
    }
}

class model extends Connector{
    function __construct(){
        parent::__construct();
    }

    function getPositions(){
      $query = "SELECT * FROM position";
        // Prepare the statement
      $stmt = $this->conn->prepare($query);
      $stmt->execute();
      return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    function getCandidates(){
      $query = "SELECT * FROM candidates cnd
                  INNER JOIN voters vv ON vv.id = cnd.voter_id
                  INNER JOIN position pp ON pp.post_id = cnd.position_id
                  ORDER BY position_name ASC";
        // Prepare the statement
      $stmt = $this->conn->prepare($query);
      $stmt->execute();
      return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    function getVoters(){
      $query = "SELECT * FROM voters";
        // Prepare the statement
      $stmt = $this->conn->prepare($query);
      $stmt->execute();
      return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    function getVotes(){
      $query = "SELECT * FROM votes 
                  INNER JOIN candidates ON candidates_id = candidate_id
                  INNER JOIN voters ON id = voter_id";
        // Prepare the statement
      $stmt = $this->conn->prepare($query);
      $stmt->execute();
      return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    function editVoter($post){
      if (isset($post['voter_id']) && isset($post['name']) && isset($post['contact']) && isset($post['address'])) {
          try {
              $sql = "UPDATE `voters` SET `name` = :name, `contact` = :con, `address` = :address WHERE id = :id";
              $query = $this->conn->prepare($sql);
              $query->execute([
                  ':id' => $post['id'],
                  ':name' => $post['name'],
                  ':con' => $post['contact'],
                  ':address' => $post['address'],
              ]);
  
              $rowsAffected = $query->rowCount();
              return $rowsAffected > 0; // Return true if at least one row was affected
  
          } catch (PDOException $e) {
              error_log($e->getMessage()); // Log the error
              echo "Database error: " . $e->getMessage(); // User-friendly message (optional in production)
              return false;
          }
      } else {
          return false; // Return false if required data is missing
      }
    }
    
    function editCandidate($post){
      if (isset($post['voter_id']) && isset($post['cnd_id']) && isset($post['position'])) {
          try {
              $sql = "UPDATE `candidates` SET `voter_id` = :voter_id, `position_id` = :post_id WHERE candidates_id = :id";
              $query = $this->conn->prepare($sql);
              $query->execute([
                  ':voter_id' => $post['voter_id'],
                  ':post_id' => $post['position'],
                  ':id' => $post['cnd_id'],
              ]);
  
              $rowsAffected = $query->rowCount();
              return $rowsAffected > 0; // Return true if at least one row was affected
  
          } catch (PDOException $e) {
              error_log($e->getMessage()); // Log the error
              echo "Database error: " . $e->getMessage(); // User-friendly message (optional in production)
              return false;
          }
      } else {
          return false; // Return false if required data is missing
      }
    }
    
    function delCandidates($post){
        //prepare the sql
        $sql = "DELETE FROM candidates WHERE candidates_id = '{$post['cnd_id']}'";												//deletedestination
        //prepare query
        $query = $this->conn->prepare($sql);
        
        //execute query
        $query->execute();
        //return
        return $query->fetchAll(PDO::FETCH_ASSOC);
    } 

    function checkerCandidate($id){
      $query = "SELECT * FROM votes WHERE candidate_id = $id";
        // Prepare the statement
      $stmt = $this->conn->prepare($query);
      $stmt->execute();
      return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    function checkerVoterIfCandidate($id){
      $query = "SELECT * FROM candidates WHERE voter_id = $id";
        // Prepare the statement
      $stmt = $this->conn->prepare($query);
      $stmt->execute();
      return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    function checkerPosition($id){
      $query = "SELECT * FROM candidates WHERE position_id = $id";
        // Prepare the statement
      $stmt = $this->conn->prepare($query);
      $stmt->execute();
      return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    function checkerVotes($id){
      $query = "SELECT * FROM votes WHERE voter_id = $id";
        // Prepare the statement
      $stmt = $this->conn->prepare($query);
      $stmt->execute();
      return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    function editPosition($post){
      if (isset($post['position']) && isset($post['id']) && isset($post['rank'])) {
          try {
              $sql = "UPDATE `position` SET `position_name` = :name, `rank` = :rank WHERE post_id = :id";
              $query = $this->conn->prepare($sql);
              $query->execute([
                  ':name' => $post['position'],
                  ':rank' => $post['rank'],
                  ':id' => $post['id'],
              ]);
  
              $rowsAffected = $query->rowCount();
              return $rowsAffected > 0; // Return true if at least one row was affected
  
          } catch (PDOException $e) {
              error_log($e->getMessage()); // Log the error
              echo "Database error: " . $e->getMessage(); // User-friendly message (optional in production)
              return false;
          }
      } else {
          return false; // Return false if required data is missing
      }
    }

    function delPosition($post){
      //prepare the sql
      $sql = "DELETE FROM position WHERE post_id = '{$post['id']}'";												//deletedestination
      //prepare query
      $query = $this->conn->prepare($sql);
      
      //execute query
      $query->execute();
      //return
      return $query->fetchAll(PDO::FETCH_ASSOC);
    }

    function addCandidates($post){
      // Proceed with the insert if the section exists
      $sql = "INSERT INTO `candidates`(`voter_id`, `position_id`) 
              VALUES ('{$post['voter_id']}', '{$post['position']}')";
  
      $query = $this->conn->prepare($sql);
      $query->execute();
      return $query->fetch(PDO::FETCH_ASSOC);
    }

    function addPosition($post){
      // Proceed with the insert if the section exists
      $sql = "INSERT INTO `position`(`position_name`, `rank`) 
              VALUES ('{$post['name']}', '{$post['rank']}')";
  
      $query = $this->conn->prepare($sql);
      $query->execute();
      return $query->fetch(PDO::FETCH_ASSOC);
    }

    function submitVotes($record, $voter){
      foreach ($record as $data) {
          $sql = "INSERT INTO `votes`(`candidate_id`, `voter_id`) VALUES (:cnd_id, :voter_id)";
          $stmt = $this->conn->prepare($sql);
          $stmt->bindParam(':voter_id', $voter);
          $stmt->bindParam(':cnd_id', $data['voted']);
          $stmt->execute();
      }
    }

    function getVoteResultByVotersId($id){
      $query = "SELECT * FROM candidates cn
                INNER JOIN voters vr ON vr.id = cn.voter_id
                INNER JOIN votes vs ON vs.voter_id = vr.id 
                INNER JOIN position ps ON ps.post_id = cn.position_id
                WHERE vs.voter_id = $id";
        // Prepare the statement
      $stmt = $this->conn->prepare($query);
      $stmt->execute();
      return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

}

?>