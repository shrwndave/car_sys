<a type="button" class="btn btn-success btn-sm" data-bs-toggle="modal" data-bs-target="#edit<?= $vts['id'] ?>">Edit</a>
                                    <div class="modal fade" id="edit<?= $vts['id'] ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog modal-dialog-centered">
                                            <div class="modal-content">
                                            <div class="modal-header">
                                                <h1 class="modal-title fs-5" id="exampleModalLabel">Edit Candidate <b style="color:green"><?= $cnd['name'] ?></b>'s Position.</h1>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <form action="?function=candidates&&sub_page=editCandidates" method="POST">
                                                <div class="modal-body">
                                                    <div class="mb-3">
                                                        <label for="name">Candidate:</label>
                                                        <select name="voter_id" class="text-center form-control" >
                                                            <option selected disabled>Choose Position</option>
                                                            <?php if(!empty($voters)): foreach($voters as $pst): ?>
                                                                <option value="<?= $pst['id'] ?>" <?php if($pst['id'] == $cnd['voter_id']){ echo "selected"; } ?>><?= $pst['name'] ?></option>
                                                            <?php endforeach; endif; ?>
                                                        </select>
                                                    </div>
                                                    <div class="mb-3">
                                                        <label for="name">Position:</label>
                                                        <select name="position" class="text-center form-control" >
                                                            <option selected disabled>Choose Position</option>
                                                            <?php if(!empty($positions)): foreach($positions as $pst): ?>
                                                                <option value="<?= $pst['post_id'] ?>" <?php if($pst['post_id'] == $cnd['post_id']){ echo "selected"; } ?>><?= $pst['position_name'] ?></option>
                                                            <?php endforeach; endif; ?>
                                                        </select>
                                                    </div>
                                                    <input type="hidden" name="cnd_id" value="<?= $cnd['candidates_id'] ?>">
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                                    <button type="submit" class="btn btn-success">Save changes</button>
                                                </div>
                                            </form>
                                            </div>
                                        </div>
                                    </div>
                                    <?php $id = $vts['id']; $checker = $model->checkerVoterIfCandidate($id); $checker1 = $model->checkerVotes($id); if($checker && $checker1 == false): ?>
                                    ||
                                    <a type="button" class="btn btn-danger btn-sm" data-bs-toggle="modal" data-bs-target="#del<?= $vts['id'] ?>">Delete</a>
                                    <div class="modal fade" id="del<?= $vts['id'] ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog modal-dialog-centered">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h1 class="modal-title fs-5" id="exampleModalLabel">Delete Candidate <b style="color:red"><?= $cnd['name'] ?></b>'s Position.</h1>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                </div>
                                                <form action="?function=candidates&&sub_page=delCandidates" method="POST">
                                                    <div class="modal-footer">
                                                        <input type="hidden" name="cnd_id" value="<?= $cnd['candidates_id'] ?>">
                                                        <button type="submit" class="btn btn-danger">Continue</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                    <?php endif; ?>