
        <div class="p-5">
            <div class="mt-5">
                <div class="table-responsive table">
                    <div class="float-end my-3"><a type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#add">Add Candidate</a></div>
                    <?php if(!empty($candidates)): ?>
                    <table id="datatablesSimple" class="table table-hover table-bordered">
                        <thead>
                            <tr class="text-center">
                                <th>No.</th>
                                <th>Name</th>
                                <th>Contact No.</th>
                                <th>Address</th>
                                <th>Position</th>
                                <th>Rank</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $n = 0; foreach($candidates as $cnd): $n++;?>
                            <tr>
                                <td class="text-center"><?= $n?></td>
                                <td><?= strtoupper($cnd['name'] )?></td>
                                <td class="text-center"><?= $cnd['contact'] ?></td>
                                <td><?= strtoupper($cnd['address']) ?></td>
                                <td><?= strtoupper($cnd['position_name']) ?></td>
                                <td class="text-center"><?= $cnd['rank'] ?></td>
                                <td class="text-center">
                                    <a type="button" class="btn btn-success btn-sm" data-bs-toggle="modal" data-bs-target="#edit<?= $cnd['candidates_id'] ?>">Edit</a>
                                    <div class="modal fade" id="edit<?= $cnd['candidates_id'] ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog modal-dialog-centered">
                                            <div class="modal-content">
                                            <div class="modal-header">
                                                <h1 class="modal-title fs-5" id="exampleModalLabel">Edit Candidate <b style="color:green"><?= $cnd['name'] ?></b>'s Position.</h1>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <form action="?function=candidates&&sub_page=editCandidates" method="POST">
                                                <div class="modal-body">
                                                    <div class="mb-3">
                                                        <label for="name">Candidate:</label>
                                                        <select name="voter_id" class="text-center form-control" >
                                                            <option selected disabled>Choose Candidate</option>
                                                            <?php if(!empty($voters)): foreach($voters as $pst): ?>
                                                                <option value="<?= $pst['id'] ?>" <?php if($pst['id'] == $cnd['voter_id']){ echo "selected"; } ?>><?= $pst['name'] ?></option>
                                                            <?php endforeach; endif; ?>
                                                        </select>
                                                    </div>
                                                    <div class="mb-3">
                                                        <label for="name">Position:</label>
                                                        <select name="position" class="text-center form-control" >
                                                            <option selected disabled>Choose Position</option>
                                                            <?php if(!empty($positions)): foreach($positions as $pst): ?>
                                                                <option value="<?= $pst['post_id'] ?>" <?php if($pst['post_id'] == $cnd['post_id']){ echo "selected"; } ?>><?= $pst['position_name'] ?></option>
                                                            <?php endforeach; endif; ?>
                                                        </select>
                                                    </div>
                                                    <input type="hidden" name="cnd_id" value="<?= $cnd['candidates_id'] ?>">
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                                    <button type="submit" class="btn btn-success">Save changes</button>
                                                </div>
                                            </form>
                                            </div>
                                        </div>
                                    </div>
                                    <?php $id = $cnd['candidates_id'];  $checker = $model->checkerCandidate($id); if($checker == false): ?>
                                    ||
                                    <a type="button" class="btn btn-danger btn-sm" data-bs-toggle="modal" data-bs-target="#del<?= $cnd['candidates_id'] ?>">Delete</a>
                                    <div class="modal fade" id="del<?= $cnd['candidates_id'] ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog modal-dialog-centered">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h1 class="modal-title fs-5" id="exampleModalLabel">Delete Candidate <b style="color:red"><?= $cnd['name'] ?></b>'s Position.</h1>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                </div>
                                                <form action="?function=candidates&&sub_page=delCandidates" method="POST">
                                                    <div class="modal-footer">
                                                        <input type="hidden" name="cnd_id" value="<?= $cnd['candidates_id'] ?>">
                                                        <button type="submit" class="btn btn-danger">Continue</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                    <?php endif; ?>
                </div>
                
            </div>
        </div>
        <div class="modal fade" id="add" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <h1 class="modal-title fs-5" id="exampleModalLabel">Add Candidate's Information.</h1>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <form action="?function=candidates&&sub_page=addCandidates" method="POST">
                        <div class="modal-body">
                            <div class="mb-3">
                                <label for="name">Candidate:</label>
                                <select name="voter_id" class="text-center form-control" >
                                    <option selected disabled>Choose Candidate</option>
                                    <?php if(!empty($voters)): foreach($voters as $pst): ?>
                                        <option value="<?= $pst['id'] ?>"><?= $pst['name'] ?></option>
                                    <?php endforeach; endif; ?>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label for="name">Position:</label>
                                <select name="position" class="text-center form-control" >
                                    <option selected disabled>Choose Position</option>
                                    <?php if(!empty($positions)): foreach($positions as $pst): ?>
                                        <option value="<?= $pst['post_id'] ?>"><?= $pst['position_name'] ?></option>
                                    <?php endforeach; endif; ?>
                                </select>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Save</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>