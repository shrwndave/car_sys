<!DOCTYPE html>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Voting System</title>
        <link rel="stylesheet" href="../assets/css/dataTables.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZwyyoJWmWvEJGg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" 
            rel="stylesheet" crossorigin="anonymous"
            integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" >
        <style>
            * {
            box-sizing: border-box;
            }

            /* Add a gray background color with some padding */
            body {
            font-family: Arial;
            padding: 20px;
            background: #f1f1f1;
            }

            /* Header/Blog Title */
            .header {
            padding: 30px;
            font-size: 40px;
            text-align: center;
            background: white;
            }

            /* Create two unequal columns that floats next to each other */
            /* Left column */
            .leftcolumn {   
            float: left;
            width: 75%;
            }

            /* Right column */
            .rightcolumn {
            float: left;
            width: 25%;
            padding-left: 20px;
            }

            /* Fake image */
            .fakeimg {
            background-color: #aaa;
            width: 100%;
            padding: 20px;
            }

            /* Add a card effect for articles */
            .card {
            background-color: white;
            padding: 20px;
            margin-top: 20px;
            }

            /* Clear floats after the columns */
            .row:after {
            content: "";
            display: table;
            clear: both;
            }

            /* Footer */
            .footer {
            padding: 20px;
            text-align: center;
            background: #ddd;
            margin-top: 20px;
            }

            /* Responsive layout - when the screen is less than 800px wide, make the two columns stack on top of each other instead of next to each other */
            @media screen and (max-width: 800px) {
            .leftcolumn, .rightcolumn {   
                width: 100%;
                padding: 0;
            }
            }
        </style>
    </head>
    <body>