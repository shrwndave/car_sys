        <div class="p-5">
            <div class="mt-5">
                <div class="table-responsive table">
                    <div class="float-end my-3"><a type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#add">Add Candidate</a></div>
                    <?php if(!empty($positions)): ?>
                    <table id="datatablesSimple" class="table table-bordered table-hover">
                        <thead>
                            <tr class="text-center">
                                <th>No.</th>
                                <th>Position Name</th>
                                <th>Rank</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $n = 0; foreach($positions as $vts): $n++;?>
                            <tr>
                                <td class="text-center"><?= $n?></td>
                                <td><?= $vts['position_name'] ?></td>
                                <td><?= $vts['rank'] ?></td>
                                <td class="text-center">
                                    <a type="button" class="btn btn-success btn-sm" data-bs-toggle="modal" data-bs-target="#edit<?= $vts['post_id'] ?>">Edit</a>
                                    <div class="modal fade" id="edit<?= $vts['post_id'] ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog modal-dialog-centered">
                                            <div class="modal-content">
                                            <div class="modal-header">
                                                <h1 class="modal-title fs-5" id="exampleModalLabel">Edit <b style="color:green"><?= $vts['position_name'] ?></b> Position.</h1>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <form action="?function=candidates&&sub_page=editPosition" method="POST">
                                                <div class="modal-body">
                                                    <div class="mb-3">
                                                        <label for="name">Position:</label>
                                                        <input type="text" name="position" class="form-control" value="<?= $vts['position_name'] ?>">
                                                    </div>
                                                    <div class="mb-3">
                                                        <label for="name">Rank:</label>
                                                        <input type="text" name="rank" class="form-control" value="<?= $vts['rank'] ?>">
                                                    </div>
                                                    <input type="hidden" name="id" value="<?= $vts['post_id'] ?>">
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                                    <button type="submit" class="btn btn-success">Save changes</button>
                                                </div>
                                            </form>
                                            </div>
                                        </div>
                                    </div>
                                    <?php $id = $vts['post_id'];  $checker = $model->checkerPosition($id); if($checker == false): ?>
                                    ||
                                    <a type="button" class="btn btn-danger btn-sm" data-bs-toggle="modal" data-bs-target="#del<?= $vts['post_id'] ?>">Delete</a>
                                    <div class="modal fade" id="del<?= $vts['post_id'] ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog modal-dialog-centered">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h1 class="modal-title fs-5" id="exampleModalLabel">Delete the <b style="color:red"><?= $vts['position_name'] ?></b>'s Position.</h1>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                </div>
                                                <form action="?function=candidates&&sub_page=delPosition" method="POST">
                                                    <div class="modal-footer">
                                                        <input type="hidden" name="id" value="<?= $vts['post_id'] ?>">
                                                        <button type="submit" class="btn btn-danger">Continue</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                    <?php endif; ?>
                </div>
                
            </div>
        </div>
        <div class="modal fade" id="add" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <h1 class="modal-title fs-5" id="exampleModalLabel">Add Candidate's Information.</h1>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <form action="?function=positions&&sub_page=addPosition" method="POST">
                        <div class="modal-body">
                            <div class="mb-3">
                                <label for="name">Position Name:</label>
                                <input type="text" name="name" class="form-control">
                            </div>
                            <div class="mb-3">
                                <label for="name">Rank:</label>
                                <input type="text" name="rank" class="form-control">
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Save</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>