
        <div class="p-5">
            <div class="mt-5">
                <div class="table-responsive table">
                    <?php if(!empty($voters)): ?>
                    <table id="datatablesSimple" class="table table-bordered table-hover">
                        <thead>
                            <tr class="text-center">
                                <th>No.</th>
                                <th>Name</th>
                                <th>Contact No.</th>
                                <th>Address</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $n = 0; foreach($voters as $vts): $n++;?>
                            <tr>
                                <td class="text-center"><?= $n?></td>
                                <td><?= $vts['name'] ?></td>
                                <td class="text-center"><?= $vts['contact'] ?></td>
                                <td><?= $vts['address'] ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                    <?php endif; ?>
                </div>
                
            </div>
        </div>