
        <div class="p-5">
            <div class="mt-5">
                <div class="table-responsive table">
                    <?php if(!empty($candidates)): ?>
                    <form action="user.php?function=vote&&sub_page=submitVotes" method="POST">
                        <input type="hidden" name="voters_id" value="<?= $_SESSION['user_id'] ?>">
                        <table id="datatablesSimple" class="table table-hover table-bordered">
                            <thead>
                                <tr class="text-center">
                                    <th>No.</th>
                                    <th>Name</th>
                                    <th>Position</th>
                                    <th>Vote</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $n = 0; foreach($candidates as $cnd): $n++;?>
                                <tr>
                                    <td class="text-center"><?= $n?></td>
                                    <td><?= strtoupper($cnd['name'] )?></td>
                                    <td><?= strtoupper($cnd['position_name']) ?></td>
                                    <td class="text-center"><input type="radio" name="vote[<?= $cnd['candidates_id'] ?>]"> Vote</td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                        <div class="float-end my-3"><input type="submit" class="btn btn-primary btn-sm"></div>
                    </form>
                    <?php endif; ?>
                </div>
                
            </div>
        </div>