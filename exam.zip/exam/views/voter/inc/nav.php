        <nav class="navbar navbar-expand-lg bg-body-tertiary fixed-top p-3">
            <div class="container-fluid d-flex">
            <?php
                if (!empty($show_offcanvas)) {
                    echo '<a class="navbar-brand" href="#">Voting System</a>';
                }else{
                    echo '<a class="navbar-brand" href="#">Voting System</a>';
                }
                ?>
                <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar" aria-controls="offcanvasNavbar">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="offcanvas offcanvas-start ms-3" tabindex="-1" id="offcanvasNavbar" aria-labelledby="offcanvasNavbarLabel">
                    <div class="offcanvas-header"> 
                        <?php $show_offcanvas = true ?>
                        <a class="navbar-brand" href="#">Voting System</a>
                        <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
                    </div>
                    <div class="offcanvas-body">
                        <ul class="navbar-nav justify-content-start flex-grow-1 pe-3 mt-2">
                            <li class="nav-item">
                                <a class="nav-link active" aria-current="page" href="?sub_page=home">Home</a>
                            </li>
                            <li class="nav-item ms-2">
                                <a class="nav-link" href="?sub_page=vote">Vote</a>
                            </li>
                            <li class="nav-item ms-2">
                                <a class="nav-link" href="?sub_page=manage_vote">Manage Votes</a>
                            </li>
                        </ul>
                        <form class="d-flex mt-3" role="search">
                            <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
                            <button class="btn btn-outline-success" type="submit">Search</button>
                        </form>
                    </div>
                </div>
                <div class="mt-3 mx-5 nav-item dropdown ">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <b><?= strtoupper($_SESSION['name']) ?></b>
                    </a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="#">Action</a></li>
                        <li><a class="dropdown-item" href="#">Another action</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="logout.php">Logout</a></li>
                    </ul>
                </div>
            </div>
        </nav>